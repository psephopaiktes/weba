console.log('aa'+$);
